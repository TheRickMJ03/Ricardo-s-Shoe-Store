<!-- 
Name: Ricardo Mejia
Date:10/05/2023
Course Name: IT202/001
Assignment: Section 001 Unit 3 Assignment 
Email: ram227@njit.edu
-->
<header> 
   
   
  
    <br>
    <h1 id= "maintitle" > "PELEGOL"</h1>
    <h2 style="font-size: 300%; color: white; ; text-align: center;font-family: fantasy ;"> Presented by Ricardo Mejia</h2>
    <h3 style="font-size: 300%; color: white; ; text-align: center;font-family: fantasy ;"> 323 Dr Martin Luther King Jr Blvd, Newark, NJ 07102</h3>
g
</header>