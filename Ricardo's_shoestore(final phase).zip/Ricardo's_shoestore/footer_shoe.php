<!-- 
Name: Ricardo Mejia
Date:10/05/2023
Course Name: IT202/001
Assignment: Section 001 Unit 3 Assignment 
Email: ram227@njit.edu
-->

<footer>
<p style="float:left;text-align: center;position:relative; left:115px ;top:13px;" >Ricardo Mejia<br>
  <a href="mailto:ram227@njit.edu">ram227@njit.edu</a></p>
  <img id= "logo3" src= "images/logo.png" alt = "logo3"  style= "width: 100px; height: 70px; background-position: center;
 position:relative; left:-110px; top:13px;  "/>
  
</footer>
