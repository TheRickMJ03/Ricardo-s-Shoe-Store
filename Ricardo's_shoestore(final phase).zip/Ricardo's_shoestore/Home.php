<!-- 
Name: Ricardo Mejia
Date:10/05/2023
Course Name: IT202/001
Assignment: Section 001 Unit 3 Assignment 
Email: ram227@njit.edu
-->

<html>
    <head>
        <link rel="stylesheet" href="Shoe_style.css">

        <title>Ricardo's Shoe Store</title>



    </head>
    <body>
       
        <?php include("header_shoe.php");?>
        <?php include("nav.php");?>
        
        <main class = "details">
            <h1 style= "color:white;">Description</h1>
            
            <h3 style= "color:white; font-family:arial"> "PELEGOL", founded in 2023, has been a 
            longstanding destination for footwear enthusiasts. Our passion and commitment lie in providing the finest selection 
            of soccer cleats to players of all levels. We recognize the profound impact quality footwear can have on performance, 
            and our purpose is to equip soccer enthusiasts with the best tools to enhance their game. Whether you're a professional
             athlete or a weekend warrior, our carefully curated collection offers a range of styles, brands, and sizes to cater to every
            player's unique needs. With our knowledgeable staff and dedication to customer satisfaction, we aim to be the ultimate
             destination for soccer cleats, where your game truly begins. Visit us today to elevate your soccer experience.
            </h3>
        </main>
       
        <img id= "logo3" src= "images/cleat2.jpg" alt = "cleat2"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
        <img id= "logo3" src= "images/cleat3.jpg" alt = "cleat3"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
        <img id= "logo3" src= "images/cleat4.jpg" alt = "cleat4"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
        <img id= "logo3" src= "images/cleat14.jpg" alt = "cleat14"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleats.jpg" alt = "cleats"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat5.jpg" alt = "cleat5.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat6.jpg" alt = "cleat6.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat7.jpg" alt = "cleat7.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat8.jpg" alt = "cleat8.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat9.jpg" alt = "cleat9.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat10.jpg" alt = "cleat10.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat11.jpg" alt = "cleat11.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat12.jpg" alt = "cleat12.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>
         <img id= "logo3" src= "images/cleat13.jpg" alt = "cleat13.jpg"  style= "width: 200px; height: 200px;
        position:relative; left:75px; top:13px;  "/>


        <?php include ("footer_shoe.php"); ?>


    </body>

</html>